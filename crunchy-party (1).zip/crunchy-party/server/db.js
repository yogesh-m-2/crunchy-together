// Crunchy Party — storage. SQLite: one file, no daemon, fine well past
// thousands of users on a small VM.

const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(process.env.DB_PATH || path.join(__dirname, "data.sqlite"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  phone         TEXT UNIQUE NOT NULL,
  created_at    INTEGER NOT NULL,
  trial_ends_at INTEGER NOT NULL,
  paid_until    INTEGER,
  sub_id        TEXT,
  sub_status    TEXT,
  blocked       INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS otps (
  phone      TEXT PRIMARY KEY,
  code_hash  TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts   INTEGER NOT NULL DEFAULT 0,
  sent_at    INTEGER NOT NULL,
  sent_count INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS webhook_events (
  id         TEXT PRIMARY KEY,
  seen_at    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_users_sub ON users(sub_id);
`);

const now = () => Date.now();

const q = {
  userByPhone: db.prepare("SELECT * FROM users WHERE phone = ?"),
  userById: db.prepare("SELECT * FROM users WHERE id = ?"),
  userBySub: db.prepare("SELECT * FROM users WHERE sub_id = ?"),
  insertUser: db.prepare(
    "INSERT INTO users (phone, created_at, trial_ends_at) VALUES (?, ?, ?)"
  ),
  setSub: db.prepare("UPDATE users SET sub_id = ?, sub_status = ? WHERE id = ?"),
  setPaid: db.prepare("UPDATE users SET paid_until = ?, sub_status = ? WHERE id = ?"),
  upsertOtp: db.prepare(`
    INSERT INTO otps (phone, code_hash, expires_at, attempts, sent_at, sent_count)
    VALUES (@phone, @code_hash, @expires_at, 0, @sent_at, 1)
    ON CONFLICT(phone) DO UPDATE SET
      code_hash = @code_hash, expires_at = @expires_at, attempts = 0,
      sent_at = @sent_at, sent_count = sent_count + 1
  `),
  getOtp: db.prepare("SELECT * FROM otps WHERE phone = ?"),
  bumpOtpAttempts: db.prepare("UPDATE otps SET attempts = attempts + 1 WHERE phone = ?"),
  clearOtp: db.prepare("DELETE FROM otps WHERE phone = ?"),
  resetOtpCount: db.prepare("UPDATE otps SET sent_count = 1 WHERE phone = ? AND sent_at < ?"),
  seenEvent: db.prepare("SELECT id FROM webhook_events WHERE id = ?"),
  markEvent: db.prepare("INSERT OR IGNORE INTO webhook_events (id, seen_at) VALUES (?, ?)"),
};

function findOrCreateUser(phone) {
  let u = q.userByPhone.get(phone);
  if (u) return u;
  const trialDays = parseInt(process.env.TRIAL_DAYS || "7", 10);
  const t = now();
  q.insertUser.run(phone, t, t + trialDays * 86400000);
  return q.userByPhone.get(phone);
}

// The single source of truth for "may this user use the product right now".
function entitlement(user) {
  const t = now();
  if (!user || user.blocked) return { active: false, reason: "blocked" };
  if (user.paid_until && user.paid_until > t) {
    return { active: true, reason: "subscribed", until: user.paid_until };
  }
  if (user.trial_ends_at > t) {
    return { active: true, reason: "trial", until: user.trial_ends_at };
  }
  return { active: false, reason: "expired", until: user.trial_ends_at };
}

module.exports = { db, q, now, findOrCreateUser, entitlement };
